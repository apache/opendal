# Dependencies

## Rust Part Dependencies

Refer to [DEPENDENCIES.rust.tsv](DEPENDENCIES.rust.tsv) for the full list.

## Nodejs Part Dependencies

No extra runtime dependencies.
