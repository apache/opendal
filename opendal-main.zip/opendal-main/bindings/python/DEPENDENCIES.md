# Dependencies

## Rust Part Dependencies

Refer to [DEPENDENCIES.rust.tsv](DEPENDENCIES.rust.tsv) for the full list.

## Python Part Dependencies

No extra runtime dependencies.
